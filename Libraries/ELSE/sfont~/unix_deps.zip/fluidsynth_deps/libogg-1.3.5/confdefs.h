/* confdefs.h */
#define PACKAGE_NAME "libogg"
#define PACKAGE_TARNAME "libogg"
#define PACKAGE_VERSION "1.3.5"
#define PACKAGE_STRING "libogg 1.3.5"
#define PACKAGE_BUGREPORT "ogg-dev@xiph.org"
#define PACKAGE_URL ""
