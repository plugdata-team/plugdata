---
title: bl.vsaw~

description:

categories:
- object

pdcategory:

arguments:
- description:
  type:
  default:

inlets:
  1st:
  - type:
    description:
  2nd:
  - type:
    description:

outlets:
  1st:
  - type:
    description:

draft: false
---

LONG DESCRIPTION HERE
