---
title: envgen~
description:
categories:
 - object
pdcategory: General
arguments:
- type: gimme
  description:
  default:
inlets:
  1st:
  - type: ?
    description:
  2nd:
  - type: ?
    description:
outlets:
  1st:
  - type: signal
    description:
  2nd:
  - type: float
    description:
