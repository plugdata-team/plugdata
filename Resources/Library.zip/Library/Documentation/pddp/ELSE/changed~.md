---
title: changed~
description:
categories:
 - object
pdcategory: General
arguments:
- type: float
  description:
  default:
inlets:
  1st:
  - type: signal
    description:
  2nd:
  - type: signal
    description:
outlets:
  1st:
  - type: signal
    description:
