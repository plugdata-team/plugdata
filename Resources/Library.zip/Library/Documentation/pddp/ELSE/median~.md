---
title: median~
description:
categories:
 - object
pdcategory: General
arguments:
- type: float
  description:
  default:
inlets:
  1st:
  - type: float
    description:
  2nd:
  - type: float
    description:
outlets:
  1st:
  - type: signal
    description:
