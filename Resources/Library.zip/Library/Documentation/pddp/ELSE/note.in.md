---
title: note.in
description:
categories:
 - object
pdcategory: General
arguments:
- type: gimme
  description:
  default:
inlets:
  1st:
  - type: float
    description:
  2nd:
  - type: float
    description:
outlets:
  1st:
  - type: float
    description:
  2nd:
  - type: float
    description:
  3rd:
  - type: float
    description:
