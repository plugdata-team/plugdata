---
title: stepnoise~
description:
categories:
 - object
pdcategory: General
arguments:
- type: float
  description:
  default:
inlets:
outlets:
  1st:
  - type: signal
    description:
