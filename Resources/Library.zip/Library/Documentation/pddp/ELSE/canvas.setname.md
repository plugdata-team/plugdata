---
title: canvas.setname
description:
categories:
 - object
pdcategory: General
arguments:
- type: symbol
  description:
  default:
- type: float
  description:
  default:
inlets:
outlets:
