
PurePd is a library of objects are written purely in Pd.  The idea is to
replace standard externals with Pd objects so that Pd its more and more a
language written in Pd.

WARNING! This library is a place for development of ideas.  Anything is up for
change given a good reason.  But be courteous: If you do change the interface
of an object in this collection, make sure that you print a warning to the Pd
window.

If you want a static, unchanging interfaces, please include it elsewhere.  If
you want a place to freely explore implementing things in Pd, please include
it in the purepd library.

<hans@at.or.at>
