---
title: buddy
description:
categories:
 - object
pdcategory: General
arguments:
- type: float
  description:
  default:
inlets:
  1st:
  - type: ?
    description:
  2nd:
  - type: ?
    description:
outlets:
  1st:
  - type: anything
    description:
  2nd:
  - type: anything
    description:
