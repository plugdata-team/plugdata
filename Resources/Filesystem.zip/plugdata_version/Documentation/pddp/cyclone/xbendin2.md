---
title: xbendin2
description:
categories:
 - object
pdcategory: General
arguments:
- type: float
  description:
  default:
inlets:
outlets:
  1st:
  - type: float
    description:
  2nd:
  - type: float
    description:
  3rd:
  - type: float
    description:
