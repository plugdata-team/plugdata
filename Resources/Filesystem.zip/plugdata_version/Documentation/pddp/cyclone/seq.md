---
title: seq
description:
categories:
 - object
pdcategory: General
arguments:
- type: symbol
  description:
  default:
inlets:
outlets:
  1st:
  - type: anything
    description:
  2nd:
  - type: bang
    description:
