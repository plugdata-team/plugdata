---
title: counter
description:
categories:
 - object
pdcategory: General
arguments:
- type: gimme
  description:
  default:
inlets:
  1st:
  - type: ?
    description:
  2nd:
  - type: ?
    description:
  3rd:
  - type: ?
    description:
  4th:
  - type: ?
    description:
  5th:
  - type: ?
    description:
outlets:
  1st:
  - type: float
    description:
  2nd:
  - type: anything
    description:
  3rd:
  - type: anything
    description:
  4th:
  - type: float
    description:
