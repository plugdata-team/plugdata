---
title: symbol2any

description: Convert symbol to anything

categories:
 - object

pdcategory: Message Management 

arguments: (none)

inlets:
  1st:
  - type: symbol
    description: symbol to be converted to any message

outlets:
  1st:
  - type: anything
    description: the converted message

draft: false
---

[symbol2any] convert symbols to any messages.
