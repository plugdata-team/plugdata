---
title: any2symbol

description: Convert anything to symbol

categories:
- object

pdcategory: General

arguments:
- description: none
  type:
  default:

inlets:
  1st:
  - type: anything
    description: any message to be converted to a symbol

outlets:
  1st:
  - type: symbol
    description: the converted symbol message

draft: false
---

[any2symbol] converts any message to a symbol message.
