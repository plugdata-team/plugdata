---
title: separate
description:
categories:
 - object
pdcategory: General
arguments:
- type: gimme
  description:
  default:
inlets:
  1st:
  - type: symbol
    description:
  2nd:
  - type: symbol
    description:
outlets:
  1st:
  - type: ?
    description:
