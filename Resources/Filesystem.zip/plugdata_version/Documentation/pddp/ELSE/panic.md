---
title: panic
description:
categories:
 - object
pdcategory: General
arguments:
inlets:
outlets:
  1st:
  - type: float
    description:
