---
title: canvas.mouse
description:
categories:
 - object
pdcategory: General
arguments:
- type: float
  description:
  default:
- type: float
  description:
  default:
inlets:
outlets:
  1st:
  - type: ?
    description:
  2nd:
  - type: 
    description:
  3rd:
  - type: 
    description:
