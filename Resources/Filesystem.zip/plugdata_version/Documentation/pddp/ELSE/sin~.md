---
title: sin~

description: Signal sine function

categories:
 - object

pdcategory: Math Functions 

arguments: (none)

inlets:
  1st:
  - type: float/signal
    description: input sine function

outlets:
  1st:
  - type: signal
    description: output of sine function

draft: false
---

[sin~] is similar to [cos~], it outputs the sine of two pi times its signal input.