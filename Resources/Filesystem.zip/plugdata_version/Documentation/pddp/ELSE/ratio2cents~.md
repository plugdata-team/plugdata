---
title: ratio2cents~
description:
categories:
 - object
pdcategory: General
arguments:
inlets:
outlets:
  1st:
  - type: signal
    description:
