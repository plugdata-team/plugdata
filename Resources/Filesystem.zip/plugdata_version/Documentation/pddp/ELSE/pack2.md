---
title: pack2
description:
categories:
 - object
pdcategory: General
arguments:
- type: gimme
  description:
  default:
inlets:
  1st:
  - type: ?
    description:
outlets:
  1st:
  - type: list
    description:
