---
title: default
description:
categories:
 - object
pdcategory: General
arguments:
- type: gimme
  description:
  default:
inlets:
  1st:
  - type: ?
    description:
  2nd:
  - type: ?
    description:
outlets:
  1st:
  - type: anything
    description:
