---
title: lincong~
description:
categories:
 - object
pdcategory: General
arguments:
- type: gimme
  description:
  default:
inlets:
outlets:
  1st:
  - type: signal
    description:
