---
title: fader~
description:
categories:
 - object
pdcategory: General
arguments:
- type: symbol
  description:
  default:
inlets:
outlets:
  1st:
  - type: signal
    description:
