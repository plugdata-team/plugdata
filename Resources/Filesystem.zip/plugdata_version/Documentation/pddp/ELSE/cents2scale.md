---
title: cents2scale

description: Cents/Scale conversion

categories:
- object

pdcategory: Tuning / Scale Tools

arguments: none

inlets:
  1st:
  - type: list
    description: cents values

outlets:
  1st:
  - type: list
    description: converted scale values

draft: false
---

Use [cents2scale] to convert a list of intervals defined as cents to a scale defined as scale steps in semitones.