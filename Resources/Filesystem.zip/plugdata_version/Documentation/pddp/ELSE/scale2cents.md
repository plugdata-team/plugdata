---
title: scale2cents

description: Scale/Cents conversion

categories:
- object

pdcategory: Scale tools

arguments: (none)

inlets:
  1st:
  - type: list
    description: scale steps

outlets:
  1st:
  - type: list
    description: converted cents values

draft: false
---

Use [scale2cents] to convert a scale defined as scale steps in semitones to cents.
