---
title: retrieve
description:
categories:
 - object
pdcategory: General
arguments:
- type: symbol
  description:
  default:
inlets:
outlets:
  1st:
  - type: anything
    description:
