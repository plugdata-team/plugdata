---
title: factor
description:
categories:
 - object
pdcategory: General
arguments:
inlets:
outlets:
  1st:
  - type: ?
    description:
