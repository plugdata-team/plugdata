---
title: ceil~

description: Ceil function (for signals)

categories:
 - object

pdcategory: Math Functions

arguments: none

inlets:
  1st:
  - type: signal
    description: input value

outlets:
  1st:
  - type: signal
    description: ceiled value

draft: false
---

[ceil~] is a ceil math function for signals.