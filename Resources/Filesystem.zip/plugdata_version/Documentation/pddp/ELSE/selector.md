---
title: selector
description:
categories:
 - object
pdcategory: General
arguments:
- type: float
  description:
  default:
- type: float
  description:
  default:
inlets:
  1st:
  - type: ?
    description:
  2nd:
  - type: ?
    description:
  3rd:
  - type: ?
    description:
outlets:
  1st:
  - type: anything
    description:
