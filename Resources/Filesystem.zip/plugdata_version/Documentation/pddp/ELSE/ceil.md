---
title: ceil

description: Ceil function

categories:
 - object

pdcategory: Math Functions

arguments: none

inlets:
  1st:
  - type: float/list
    description: input value(s) to ceil function

outlets:
  1st:
  - type: float/list
    description: output value(s) of ceil function

draft: false
---

[ceil] is a ceil math function.