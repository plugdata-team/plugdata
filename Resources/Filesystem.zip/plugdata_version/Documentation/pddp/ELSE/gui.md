---
title: gui
description:
categories:
 - object
pdcategory: General
arguments:
inlets:
outlets:
