---
title: susloop~
description:
categories:
 - object
pdcategory: General
arguments:
- type: gimme
  description:
  default:
inlets:
  1st:
  - type: signal
    description:
  2nd:
  - type: signal
    description:
outlets:
  1st:
  - type: signal
    description:
  2nd:
  - type: float
    description:
