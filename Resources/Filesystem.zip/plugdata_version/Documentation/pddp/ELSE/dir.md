---
title: dir
description:
categories:
 - object
pdcategory: General
arguments:
- type: gimme
  description:
  default:
inlets:
outlets:
  1st:
  - type: anything
    description:
  2nd:
  - type: symbol
    description:
  3rd:
  - type: float
    description:
  4th:
  - type: float
    description:
