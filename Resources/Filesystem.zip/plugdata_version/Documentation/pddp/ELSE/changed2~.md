---
title: changed2~
description:
categories:
 - object
pdcategory: General
arguments:
inlets:
outlets:
  1st:
  - type: signal
    description:
  2nd:
  - type: signal
    description:
